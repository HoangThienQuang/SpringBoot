package Demo01.demov1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demov1Application {

	public static void main(String[] args) {
		SpringApplication.run(Demov1Application.class, args);
	}

}
